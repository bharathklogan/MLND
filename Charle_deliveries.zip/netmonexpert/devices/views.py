from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from .forms import AddDeviceForm,ManageDevicesForm
from django.urls import reverse
from django.contrib import messages
from .models import Devices





# Create your views here.
@login_required
def home(request):
    context = {'test' : 'test'}
    return render(request,"devices/home.html",context)
	
@login_required	
def add_device(request):
    return HttpResponse("This is Add Device Page")

@login_required	
def update_device(request,):
    return HttpResponse("This is Update Device Page")
		
@login_required
def manage_device(request):
    return HttpResponse("This is Manage Device Page")

@login_required
def search_results(request):
    return HttpResponse("This is Search Results Page")
