from django import forms
from .models import Devices

class AddDeviceForm(forms.ModelForm):
    class Meta:
        model = Devices
        fields = [ 'device_name', 'address', 'city', 'vendor', 'management_ip', 'site']
		
    def clean(self,*args, **kwargs):
        super(AddDeviceForm,self).clean(*args,**kwargs)
        mgt_ip = self.cleaned_data.get('management_ip')
        print("IPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP", mgt_ip)
        #ip = Devices.objects.filter(management_ip=mgt_ip)
        #print("IIIIIIIIIIIIIIIII is",ip)
        if Devices.objects.filter(management_ip=mgt_ip).exists():
            raise forms.ValidationError("This IP is already exists. Please use another IP")
			
        return self.cleaned_data
		
		
class ManageDevicesForm(forms.ModelForm):
    class Meta:
        model = Devices
        fields = ['management_ip','site']
		
    def  __init__(self,*args,**kwargs):
        super(ManageDevicesForm,self).__init__(*args,**kwargs)
        self.fields['management_ip'].required = False
        self.fields['site'].required = False
		
	
	

