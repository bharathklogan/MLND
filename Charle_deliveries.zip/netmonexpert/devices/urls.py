from django.conf.urls import url,include
from django.contrib.auth import views as auth_views
from django.core.urlresolvers import reverse_lazy
#from django.core.urlresolvers import reverse

from .views import (
        home,
        add_device,
        update_device,
        manage_device,
        search_results,
	)
   
urlpatterns = [
    url(r'^home/$',home, name='home'),
    url(r'^add/$', add_device, name='add_device'),
    url(r'^update/$', update_device, name='update_device'),
    url(r'^manage/$', manage_device, name='manage_device'),
    url(r'^search_results/$', search_results, name='search_results'),
    #url(r'^results/$', views.home, name='home'),
    #url(r'^ssh_login/$', views.home, name='home'),
    #url(r'^show_cmds/$', views.home, name='home'),
    #url(r'^custom/$', views.home, name='home'),
    #url(r'^output/$', views.home, name='home'),
    
]
        