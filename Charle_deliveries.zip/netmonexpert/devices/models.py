from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
# Create your models here.

class Devices(models.Model):

    user = models.ForeignKey(User)
    device_name = models.CharField(max_length=35)
    address = models.TextField()
    city = models.CharField(max_length=25)
    vendor = models.CharField(max_length=35)
    management_ip = models.GenericIPAddressField(protocol='both')
    site = models.CharField(max_length=25)

    def __unicode__(self):
        return 'Device Name is %s , IP = %d' (self.device_name,self.management_ip)
	
    def __str__(self):
        return 'Device Name is %s , IP = %d' (self.device_name,self.management_ip)
		
    def get_absolute_url(self):
        return reverse("home")        
		
		
	
	
	
