from django.contrib.auth import (
    authenticate,
    get_user_model,
    login,
    logout,
    )
from django.http import HttpResponse,HttpResponseRedirect
from django.template import loader,context
from django.contrib import messages
from django.shortcuts import render,redirect
from django.urls import reverse
from django.contrib.auth.models import User



from .forms import UserLoginForm, UserRegisterForm


# Create your views here.
def register(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse("home"))
    
    if request.method == 'POST':
        form = UserRegisterForm(request.POST or None)	
        if not form.is_valid():
            messages.add_message(request, messages.ERROR, 'There was some problems while creating your account. Please review some fields before submiting again.')
            context = {'form': form}
            return render(request,'accounts/registration_form.html', context)
        else:
            username = form.cleaned_data.get('username')
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            User.objects.create_user(username=username, password=password, email=email)
            template = loader.get_template("accounts/registration_complete.html")
            return HttpResponse(template.render())
    else:
   
        form = UserRegisterForm()
        return render(request,'accounts/registration_form.html', {'form' : form})


	
def index(request):
    if request.user.is_authenticated:
        return HttpResponseRedirect(reverse("home"))
    else:
        return HttpResponseRedirect(reverse("login"))
