from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.decorators import login_required
from .forms import AddDeviceForm,SSHLoginForm,UpdateForm
#from django.urls import reverse
from django.core.urlresolvers import reverse
from django.contrib import messages
from .models import Devices
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import platform, os, subprocess
from django.http import JsonResponse
import json
import time 
import paramiko
from collections import defaultdict





# Create your views here.
@login_required
def home(request):
    return render(request,"devices/home.html")
	
@login_required	
def add_device(request):
    if request.method == 'POST':
        form = AddDeviceForm(request.POST or None)
		
        if form.is_valid():
            device = form.save(commit=False)
            device.user = request.user
            device.save()
            return HttpResponseRedirect(reverse("home"))
        else:
            return render(request,'devices/add_device.html', {'form' : form })
    else:
        form = AddDeviceForm()
        return render(request,'devices/add_device.html', {'form' : form })
		

@login_required	
def update_device(request,id):
    instance = get_object_or_404(Devices, id=id)
    form = UpdateForm(request.POST or None, instance=instance)
    if request.method == 'POST':
        if form.is_valid():
            vendor_f = form.cleaned_data['vendor']
            site_f = form.cleaned_data['site']
            instance.vendor = vendor_f
            instance.site = site_f
            instance.save()
            return HttpResponseRedirect(reverse("home"))
        else:
            form = UpdateForm()
            return render(request,'devices/update.html', {'form' : form })
    else:
        return render(request,'devices/update.html', {'form' : form })

		
@login_required
def manage_device(request):
    return render(request,"devices/manage_devices.html")

@login_required
def search_results(request):
    if request.GET.get('management_ip') is None and request.GET.get('site') is None:
        messages.error(request, "Please provide IP or Site to get the search results..!")
        return render(request,"devices/manage_devices.html")
   
    elif request.GET.get('management_ip') and request.GET.get('site'):
        messages.error(request, "Please provide either IP OR Site only and not both..!")
        return render(request,"devices/manage_devices.html")
        
    elif request.GET.get('management_ip'):
        ip = request.GET.get('management_ip')
        ips_list = ip.split(",")
        query_list = Devices.objects.filter(management_ip__in=ips_list).values()
        if not query_list:
            messages.error(request, "No results found for the given IP...!")
            return render(request,"devices/manage_devices.html")
    elif request.GET.get('site'):
        site = request.GET.get('site')
        site_list = site.split(",")
        query_list = Devices.objects.filter(site__in=site_list).values()
		
        if not query_list:
            messages.error(request, "No results found for the given site...!")
            return render(request,"devices/manage_devices.html")
        #return render(request,"devices/manage_devices.html",)
    ip_list = []
    for q_vals in query_list:
        vals = q_vals.copy() 
        for k,v in q_vals.iteritems():
            if k == 'id':
                obj = Devices.objects.get(id=v)
                ip = obj.management_ip
                status = subprocess.call(
                     ['ping', '-c1', '-W10', '-w2', ip],
                stdout = open(os.devnull, 'wb'))
                #print("sssssssssssssssssssssssssssssssssssssssssssssssssssssssss", status)
                ping_str = "-n 1" if  platform.system().lower()=="windows" else "-c 1"
                # Ping
                #status = os.system("ping " + ping_str + " " + ip)
                if status == 0:
                    vals['status'] = 'UP'
                else:
                    vals['status'] = 'DOWN'
                ip_list.append(vals)
                    
    query_list = ip_list
        
    page_request_var = "page"
    page = request.GET.get(page_request_var)	
    paginator = Paginator(query_list, 7) 
    #paginator = Paginator(query_list, 4) 

    try:
        queryset = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        queryset = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        queryset = paginator.page(paginator.num_pages)


    context = {
        "object_list": queryset, 
        #"title": "List",
        "page_request_var": page_request_var,
        #"today": today,
    }
    return render(request,"devices/results.html",context)
	

	
@login_required
def ping_check(request,id):
    
    if request.is_ajax():
        obj = Devices.objects.get(id=id)
        ip = obj.management_ip
        	
        # status = subprocess.call(
            # ['ping', '-c1', '-W10', '-w2', ip],
        # stdout = open(os.devnull, 'wb'))
    
        ping_str = "-n 1" if  platform.system().lower()=="windows" else "-c 1"
		# Ping
        status = os.system("ping " + ping_str + " " + ip)
        return status
        #data = json.dumps(status)
      
        #return HttpResponse(data, content_type='application/json')

	
	
@login_required
def ssh_login(request,id):
    obj = Devices.objects.get(id=id)
    devicename = obj.device_name
    ip = obj.management_ip
    if request.method == 'POST':
        form = SSHLoginForm(request.POST or None, initial={
            'device_name': devicename,
            'management_ip' :  ip,
        })
        if form.is_valid():
            sshuser = request.POST.get("ssh_username")
            sshpassword = request.POST.get("ssh_password")
            if request.POST.get("show"):
                return HttpResponseRedirect(reverse('commands_option', kwargs = {'device_id': id,'usern' : sshuser, 'pwd' : sshpassword,}  ))
            elif request.POST.get("custom"):
                return HttpResponseRedirect(reverse('custom_commands', kwargs = {'device_id': id,'usern' : sshuser, 'pwd' : sshpassword} ))
        else:
            return render(request,'devices/ssh_login.html', context)
    else:
        form = SSHLoginForm(initial={'device_name': devicename,'management_ip':ip})
        return render(request,'devices/ssh_login.html', {'form' : form } )
		


@login_required		
def commands_option(request,device_id,usern,pwd):
    context = {
        'device_id' : device_id,
        'usern' : usern,
        'pwd' : pwd,
        'commands_option' : commands_option 
    }
    return render(request,'devices/commands_option.html',context)    
    
    

@login_required		
def show_commands(request,device_id=0,usern=None,pwd=None,commands_option=1):
    device_id = request.GET.get("device_id")
    usern = request.GET.get("usern")
    pwd = request.GET.get("pwd")
    commands_option = request.GET.get("commands_option")
    context = {
        'device_id' : device_id,
        'usern' : usern,
        'pwd' : pwd,
        'commands_option' : commands_option
    }
    obj = Devices.objects.get(id=device_id)
    devicename = obj.device_name
    ip = obj.management_ip
    if request.GET.get("showrun"):
        dest_comm = "show run"
    elif request.GET.get("interstatus"):
        dest_comm = "show inter status"
    elif request.GET.get("ipinterbrief"):
        dest_comm = "show ip inter brief"
    elif request.GET.get("ipospfnei"):
        dest_comm = "show ip ospf nei"
    elif request.GET.get("showlogging"):
        dest_comm = "show logging"
    elif request.GET.get("showversion"):
        dest_comm = "show version"
    elif request.GET.get("ls"):
        dest_comm = "/bin/ls -ltr"
	    
    else:
        messages.success(request, 'Command Executed Successfully and Output is given below')
    cmd_inp = {}
    cmd_inp['ip'] = ip
    cmd_inp['username'] = usern
    cmd_inp['password'] = pwd
    cmd_inp['command'] = dest_comm
    status = {}
    status = execute_command(**cmd_inp)

    if status['status'] == 2:
        messages.error(request, "Something went wrong during authentication. Please check username and password. Please go back to ssh page and verify them..")
        return render(request,"devices/show_cmds.html", context)
    elif status['status'] == 0:	
        context['output_msg'] = "The output is given below"
        context['output'] = status['output']
        return render(request,"devices/show_cmds.html",context )
    for key in request.GET:  # "for key in request.GET" works too.
    # Add filtering logic here.
        valuelist = request.GET.getlist(key)

    return render(request,'devices/commands_option.html', context)
	

@login_required		
def custom_commands(request,device_id,usern,pwd):
    obj = Devices.objects.get(id=device_id)
    #devicename = obj.device_name
    ip = obj.management_ip
    if request.GET.get("custom_command"):
        dest_comm = request.GET.get("custom_command")
        cmd_inp = {}
        cmd_inp['ip'] = ip
        cmd_inp['username'] = usern
        cmd_inp['password'] = pwd
        cmd_inp['command'] = dest_comm
        status = execute_command(**cmd_inp)
        if status['status'] == 2:
            #messages.error(request, "Something went wrong during authentication. Please check username and password!")
            messages.error(request, "Something went wrong during authentication. Please check username and password. Please go back to ssh page and verify them..")
            return render(request,"devices/custom.html", { 'device_id' : device_id})
        elif status['status'] == 0:	
            context = { 
                'device_id' : device_id,
                'output' : status['output'],
                'output_msg' : "The output is given below"
            }
            #messages.success(request, 'Command Executed Successfully and Output is given below')
            return render(request,"devices/custom.html",context)
    else:
        return render(request,'devices/custom.html', {'device_id' : device_id})
    
    
def execute_command(**cmd_inp):
    ip=str(cmd_inp['ip'])
    fusern=str(cmd_inp['username'])
    fpassw=str(cmd_inp['password'])
    des_comm=str(cmd_inp['command'])
    out_st = {}
    try:
        # store paramiko ssh client func in variable called "session"
        #des_comm="ls -l"
        session = paramiko.SSHClient()
        # ignore lack of host rsa key
        session.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        # connect to the box
        session.connect(ip, username = fusern, password = fpassw)
        # make it an interactive session
        connection = session.invoke_shell()
        # send term length 0 to the box and then user's command
        connection.send("term len 0\n")
        connection.send("%s\n" % des_comm)
        time.sleep(1)
        # store command's output in variable and then print it
        output = connection.recv(65535)
        status = 0

        session.close()
        #output = list(output)
        out_st['status'] = status
        out_st['output'] = output
        #context = {'output' : output}
        return  out_st
    # if failed to authenticate
    except paramiko.AuthenticationException:
        out_st['status'] = 2
        session.close()
        return out_st
    #return HttpResponse(output)
	

