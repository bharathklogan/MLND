from django.conf.urls import url,include
from django.contrib.auth import views as auth_views
from django.core.urlresolvers import reverse_lazy
#from django.core.urlresolvers import reverse

from .views import (
        home,
        add_device,
        update_device,
        manage_device,
        search_results,
        ping_check,
        ssh_login,
	show_commands,
	commands_option,
	custom_commands,
		
	)
   
urlpatterns = [
    url(r'^home/$',home, name='home'),
    url(r'^add/$', add_device, name='add_device'),
    url(r'^update/(?P<id>[0-9]+)/$', update_device, name='update_device'),
    url(r'^manage/$', manage_device, name='manage_device'),
    url(r'^search_results/$', search_results, name='search_results'),
    url(r'^ping_check/(?P<id>[0-9]+)/$', ping_check, name='ping_check'),
    url(r'^ssh_login/(?P<id>[0-9]+)/$', ssh_login, name='ssh_login'),
    url(r'^commands_option/(?P<device_id>[0-9]+)/(?P<usern>.*)/(?P<pwd>.*)/$', commands_option, name='commands_option'),
    url(r'^show_cmds/$', show_commands, name='show_commands'),
    url(r'^show_cmds/(?P<device_id>[0-9]+)/(?P<usern>.*)/(?P<pwd>.*)/$', show_commands, name='show_commands'),
    url(r'^custom/(?P<device_id>[0-9]+)/(?P<usern>.*)/(?P<pwd>.*)/$', custom_commands, name='custom_commands'),
    #url(r'^output/$', views.home, name='home'),
    #url(r'^error/$', views.home, name='home'),
    
]
