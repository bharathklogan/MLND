$(document).on("click","a[name='managementip']", function (e) {
    var result = $(this).parent().next('td').text();
	if( result != 'UP' && result != 'DOWN') {
		alert('Please check the status of the server to proceed further..');
		e.preventDefault();
	} else if (result == 'DOWN') {
		alert('You cannot acces the server that is down.');
		e.preventDefault();
	} else {
	//	alert('Something wrong. Please try again.');
	//	e.preventDefault();
	}
		
});

		

$(document).ready(function() {
/*
	$('.btn.btn-info').on('click', function(e){
		var ping_id = this.id;
		var ids = ping_id.split('_');
		var url = "/devices/ping_check/" + ids[1]
		
		alert('Please wait till the page loads. It might take few seconds to check the status of servers...');
		$.ajax({
            type: "GET",
            url: url,
			beforeSend: function() { $('#loading-indicator').show(); },
			complete: function() { 
				$('#loading-indicator').hide(); 
				
			},
			
            success: function(data) {
				if (data == 0) {
					$("#" + ping_id).attr('class', 'btn btn-success');
					$("#" + ping_id).text('UP');
				}	
				else {
					$("#" + ping_id).attr('class', 'btn btn-danger');
					$("#" + ping_id).text('DOWN');
				}
			},
			error: function(data) {
				alert("Not able to ping...Please try after sometime");
			}
	    });
		
	});

*/
	$('#search_ips').on('click', function(e){
		alert('Going to check the status of server(s)...');
	});
});	
/*
$(document).ready(function() {
	$('.btn.btn-primary.btn-show_cmds-ver').on('click', function(e){
	alert('Please wait till the page loads. It might take few seconds.');
	});

	$('.btn.btn-primary.btn-custom').on('click', function(e){
        alert('Please wait till the page loads. It might take few seconds.');
        });

})
*/
